package org.sid.cinema.web;
import java.util.List;

import org.sid.cinema.dao.*;
import org.sid.cinema.modele.Cinema;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin(origins="*",allowedHeaders="*")
@RequestMapping("/cinema")
public class CinemaRestController {
	@Autowired
	private CinemaRepository cinemaRepository;
	
	
	@GetMapping({"/",""})
	public List<Cinema> All(){
		return cinemaRepository.findAll();
	}
	
	@GetMapping("/{id}")
	public Cinema cinema(@PathVariable Long id) {
		return cinemaRepository.findById(id).get();
	}
	
	@PostMapping("/")
	public Cinema save(@RequestBody Cinema cinema) {
		return cinemaRepository.save(cinema);
	}
	
	@DeleteMapping("/{id}")
	public void delete(@PathVariable Long id) {
		 cinemaRepository.deleteById(id);
	}
	
	@PutMapping("/{id}")
	public Cinema update(@RequestBody Cinema cinema,@PathVariable Long id) {
		 cinema.setId(id);
		 return cinemaRepository.save(cinema);
	}
	

}
/*
 * import java.io.File; import java.io.IOException; import java.nio.file.Files;
 * import java.nio.file.Path; import java.nio.file.Paths; import
 * java.util.ArrayList; import java.util.List;
 * 
 * import javax.transaction.Transactional;
 * 
 * import org.sid.cinema.dao.FilmRepository; import
 * org.sid.cinema.dao.TicketRepository; import org.sid.cinema.entities.Film;
 * import org.sid.cinema.entities.Ticket; import
 * org.springframework.beans.factory.annotation.Autowired; import
 * org.springframework.http.MediaType; import
 * org.springframework.web.bind.annotation.CrossOrigin; import
 * org.springframework.web.bind.annotation.GetMapping; import
 * org.springframework.web.bind.annotation.PathVariable; import
 * org.springframework.web.bind.annotation.PostMapping; import
 * org.springframework.web.bind.annotation.RequestBody; import
 * org.springframework.web.bind.annotation.RestController;
 * 
 * import lombok.Data;
 * 
 * @RestController
 * 
 * @CrossOrigin("*") public class CinemaRestController {
 * 
 * @Autowired private FilmRepository filmRepository;
 * 
 * @Autowired private TicketRepository ticketRepository;
 * 
 * @GetMapping(path="/imageFilm/{id}",produces=MediaType.IMAGE_JPEG_VALUE)
 * public byte[] image(@PathVariable (name="id") Long id) throws IOException {
 * Film f=filmRepository.findById(id).get(); String photoName=f.getPhoto(); File
 * file=new File(System.getProperty("user.home")+"/cinema/images/"+photoName);
 * Path path=Paths.get(file.toURI()); return Files.readAllBytes(path); }
 * 
 * @PostMapping("/payerTickets")
 * 
 * @Transactional public List<Ticket> payerTickets(@RequestBody TicketFrom
 * ticketFrom) { List<Ticket> listTickets=new ArrayList<>();
 * ticketFrom.getTickets().forEach(idTicket->{ Ticket
 * ticket=ticketRepository.findById(idTicket).get();
 * ticket.setNomClient(ticketFrom.getNomClient()); ticket.setReserve(true);
 * ticketRepository.save(ticket); listTickets.add(ticket);
 * 
 * }); return listTickets; } }
 * 
 * @Data class TicketFrom{ private String nomClient; private int codePayement;
 * private List<Long> tickets=new ArrayList();
 * 
 * }
 */