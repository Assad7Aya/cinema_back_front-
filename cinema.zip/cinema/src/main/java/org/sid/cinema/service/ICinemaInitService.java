package org.sid.cinema.service;

import org.springframework.web.bind.annotation.CrossOrigin;

@CrossOrigin("*")
public interface ICinemaInitService {

	public void initVilles();
	public void initCinemas();
	public void initSalles();
	public void initPlaces();
	public void initSeances();
	public void initCategories();
	public void initFilms();
	public void initProjections();
	public void initTickets();
	




}
